# js
Add your javascript to this directory. For performance reasons, you should concatenate your scripts into a single file if you can.
