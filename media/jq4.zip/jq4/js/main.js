$(document).ready(function () {

    myScrollToFunction("s");
    myStickyFunction();
    myScrollingFunction();
    myParallaxFunction();

    var l = function(passedValue, somethingElse) {

      // console.log(passedValue);
      // console.log(somethingElse);
      if ( passedValue < 5) {
        return(true);
      }
      if ( somethingElse < 10 ) {
        return("this is a small number");
      } else {
        return("nope");
      }

    };

    // $('div').append("string of text");
    // $("header").css('content', "some content here");

    // l("thing 1", "hi");
    // l("thing 2", 2);
    // l("thing 3", true);

    console.log( l(6, 10) );





});
