


$(document).ready(function () {

  $('.btn-primary').on('click', function(e){
    e.preventDefault();
    $(".btn-primary").ScrollTo({
        duration: 1000,
        callback: function(){ // run a callback function when the animation finishes
          $(".navbar").addClass("animated fadeOutUp");
          $("#footer").addClass("animated shake");
        }
    });
  });
  // add a parallax effect to the jumbotron title element
  $('.jumbotron').parallax({
    imageSrc: 'media/screen.png',
    speed: -0.5
    });

  // $(".jumbotron").scrollTop( 200 );
  $(window).scroll(function () {
    // detect when the window is being scrolled
    // console.log("I'm scrolling");
    // console.log( $(this).scrollTop() );

  });



});
